import React, { useState } from 'react';
import {
  Text,
  View,
  StyleSheet,
  TextInput,
  TouchableOpacity,
} from 'react-native';
import Constants from 'expo-constants';

export default function App() {
  // Menampung data
  const [name, setName] = useState('');
  const [gender, setGender] = useState('');
  const [email, setEmail] = useState('');
  const [status, setStatus] = useState('');

  const [loading, setLoading] = useState(false);

  const saveData = () => {
    setLoading(true);

    const myHeaders = new Headers();

    myHeaders.append(
      'Authorization',
      'Bearer a0bbbf81084293a753e003b143d1be1b2fe7cfe51a1538304dd7e9966aabd137'
    );

    myHeaders.append('Content-Type', 'application/json');

    fetch('https://gorest.co.in/public-api/users', {
      method: 'POST',
      headers: myHeaders,
      body: JSON.stringify({
        name: name,
        email: email,
        gender: gender,
        status: status,
      }),
    })
      .then(() => {
        console.log('Berhasil post data');
        setLoading(false);
        setName('');
        setGender('');
        setEmail('');
        setStatus('');
      })
      .catch((error) => console.log(error));
  };

  return (
    <View style={styles.container}>
      <Text style={styles.title}>INPUT DATA</Text>
      <TextInput
        placeholder={'enter name'}
        value={name}
        onChangeText={(value) => setName(value)}
        style={styles.textInput}
      />
      <TextInput
        placeholder={'enter gender'}
        value={gender}
        onChangeText={(value) => setGender(value)}
        style={styles.textInput}
      />
      <TextInput
        placeholder={'enter email'}
        value={email}
        onChangeText={(value) => setEmail(value)}
        style={styles.textInput}
      />
      <TextInput
        placeholder={'enter status'}
        value={status}
        onChangeText={(value) => setStatus(value)}
        style={styles.textInput}
      />
      <TouchableOpacity onPress={saveData}>
        <View style={styles.button}>
          <Text style={styles.buttonText}>
            {loading ? 'Saving...' : 'Save'}
          </Text>
        </View>
      </TouchableOpacity>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    paddingHorizontal: 20,
    paddingTop: Constants.statusBarHeight,
    backgroundColor: '#ecf0f1',
    padding: 8,
  },
  title: {
    fontSize: 24,
    color: 'teal',
    textAlign: 'center',
    fontWeight: 'bold',
    marginTop: 60,
    marginBottom: 20,
  },
  textInput: {
    height: 50,
    borderWidth: 1,
    borderColor: '#ccc',
    borderRadius: 10,
    padding: 10,
    marginVertical: 10,
  },
  button: {
    backgroundColor: 'teal',
    padding: 10,
    borderRadius: 10,
    marginTop: 20,
  },
  buttonText: {
    color: 'white',
    textAlign: 'center',
  },
});

// from Ipung Dev
// import React, { useState } from 'react';
// import {
//   Text,
//   View,
//   StyleSheet,
//   TextInput,
//   TouchableOpacity,
// } from 'react-native';
// import Constants from 'expo-constants';

// export default function App() {
//   // Menampung data
//   const [user, setUser] = useState({
//     name: '',
//     email: '',
//     gender: '',
//     status: '',
//   });

//   const [loading, setLoading] = useState(false);

//   const onChangeName = (value) => {
//     setUser({ ...user, name: value });
//   };

//   const onChangeEmail = (value) => {
//     setUser({ ...user, email: value });
//   };

//   const onChangeGender = (value) => {
//     setUser({ ...user, gender: value });
//   };

//   const onChangeStatus = (value) => {
//     setUser({ ...user, status: value });
//   };

//   const saveData = () => {
//     setLoading(true);
//     let myHeaders = new Headers();

//     myHeaders.append(
//       'Authorization',
//       'Bearer a0bbbf81084293a753e003b143d1be1b2fe7cfe51a1538304dd7e9966aabd137'
//     );

//     myHeaders.append('Content-Type', 'application/json');

//     fetch('https://gorest.co.in/public-api/users', {
//       method: 'POST',
//       headers: myHeaders,
//       body: JSON.stringify({
//         name: user.name,
//         email: user.email,
//         gender: user.gender,
//         status: user.status,
//       }),
//     })
//       .then((response) => {
//         response.json();
//         setLoading(false);
//         setUser('')
//       })
//       .then((json) => console.log(json))
//       .catch((error) => console.log(error));
//   };

//   return (
//     <View style={styles.container}>
//       <TextInput
//         placeholder={'enter your name'}
//         onChangeText={(value) => onChangeName(value)}
//         style={styles.textInput}
//       />
//       <TextInput
//         placeholder={'enter your gender'}
//         onChangeText={(value) => onChangeGender(value)}
//         style={styles.textInput}
//       />
//       <TextInput
//         placeholder={'enter your email'}
//         onChangeText={(value) => onChangeEmail(value)}
//         style={styles.textInput}
//       />
//       <TextInput
//         placeholder={'enter your status'}
//         onChangeText={(value) => onChangeStatus(value)}
//         style={styles.textInput}
//       />
//       <TouchableOpacity onPress={saveData}>
//         <View style={styles.button}>
//           <Text style={styles.buttonText}>
//             {loading ? 'Saving...' : 'Save'}
//           </Text>
//         </View>
//       </TouchableOpacity>
//     </View>
//   );
// }

// const styles = StyleSheet.create({
//   container: {
//     flex: 1,
//     paddingHorizontal: 20,
//     paddingTop: Constants.statusBarHeight,
//     backgroundColor: '#ecf0f1',
//     padding: 8,
//   },
//   textInput: {
//     height: 50,
//     borderWidth: 1,
//     borderColor: '#ccc',
//     borderRadius: 10,
//     padding: 10,
//     marginVertical: 10,
//   },
//   button: {
//     backgroundColor: 'teal',
//     padding: 10,
//     borderRadius: 10,
//     marginTop: 20,
//   },
//   buttonText: {
//     color: 'white',
//     textAlign: 'center',
//   },
// });
