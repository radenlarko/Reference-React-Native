import Details from './Details';
import Get from './Get';
import Post from './Post';

export {Details, Get, Post};