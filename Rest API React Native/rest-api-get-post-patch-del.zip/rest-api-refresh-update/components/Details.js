import React, {Component, useState} from 'react'
import { StyleSheet, Text, View, TextInput, TouchableOpacity } from 'react-native'
import Constants from 'expo-constants';

const Details = ({route, navigation}) => {
  const {item} = route.params;
  const [name, setName] = useState(item.name);
  const [gender, setGender] = useState(item.gender);
  const [email, setEmail] = useState(item.email);
  const [status, setStatus] = useState(item.status);

  const [loadingUpdate, setLoadingUpdate] = useState(false);
  const [loadingDelete, setLoadingDelete] = useState(false);

  const updateData = () => {
    setLoadingUpdate(true);

    const myHeaders = new Headers();

    myHeaders.append(
      'Authorization',
      'Bearer a0bbbf81084293a753e003b143d1be1b2fe7cfe51a1538304dd7e9966aabd137'
    );

    myHeaders.append('Content-Type', 'application/json');

    const endpoint = 'https://gorest.co.in';

    fetch(`${endpoint}/public-api/users/${item.id}`, {
      method: 'PATCH',
      headers: myHeaders,
      body: JSON.stringify({
        name: name,
        email: email,
        gender: gender,
        status: status,
      }),
    })
      .then(() => {
        console.log('Berhasil update data');
        setLoadingUpdate(false);
        navigation.navigate('Get');
      })
      .catch((error) => console.log(error));
  }

  const deleteData = () => {
    setLoadingDelete(true);

    const myHeaders = new Headers();

    myHeaders.append(
      'Authorization',
      'Bearer a0bbbf81084293a753e003b143d1be1b2fe7cfe51a1538304dd7e9966aabd137'
    );

    myHeaders.append('Content-Type', 'application/json');

    const endpoint = 'https://gorest.co.in';

    fetch(`${endpoint}/public-api/users/${item.id}`, {
      method: 'DELETE',
      headers: myHeaders,
    })
      .then(() => {
        console.log('Berhasil delete data');
        setLoadingDelete(false);
        navigation.navigate('Get');
      })
      .catch((error) => console.log(error));
  }

  return (
    <View style={styles.container}>
      <TextInput
        placeholder={'enter name'}
        value={name}
        onChangeText={(value) => setName(value)}
        style={styles.textInput}
      />
      <TextInput
        placeholder={'enter gender'}
        value={gender}
        onChangeText={(value) => setGender(value)}
        style={styles.textInput}
      />
      <TextInput
        placeholder={'enter email'}
        value={email}
        onChangeText={(value) => setEmail(value)}
        style={styles.textInput}
      />
      <TextInput
        placeholder={'enter status'}
        value={status}
        onChangeText={(value) => setStatus(value)}
        style={styles.textInput}
      />
      <TouchableOpacity onPress={updateData}>
        <View style={styles.buttonUpdate}>
          <Text style={styles.buttonText}>
            {loadingUpdate ? 'Updating...' : 'Update'}
          </Text>
        </View>
      </TouchableOpacity>
      <TouchableOpacity onPress={deleteData}>
        <View style={styles.buttonDelete}>
          <Text style={styles.buttonText}>
            {loadingDelete ? 'Deleting...' : 'Delete'}
          </Text>
        </View>
      </TouchableOpacity>
    </View>
  )
}


const styles = StyleSheet.create({
  container: {
    flex: 1,
    paddingHorizontal: 20,
    paddingTop: Constants.statusBarHeight,
    backgroundColor: '#ecf0f1',
    padding: 8
  },
  textInput: {
    height: 50,
    borderWidth: 1,
    borderColor: '#ccc',
    borderRadius: 10,
    padding: 10,
    marginVertical: 10,
  },
  buttonUpdate: {
    backgroundColor: 'teal',
    padding: 10,
    borderRadius: 10,
    marginTop: 20,
  },
  buttonDelete: {
    backgroundColor: 'tomato',
    padding: 10,
    borderRadius: 10,
    marginTop: 5,
  },
  buttonText: {
    color: 'white',
    textAlign: 'center',
  }
})

export default Details