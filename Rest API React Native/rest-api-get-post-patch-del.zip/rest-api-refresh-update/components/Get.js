import React, {Component, useState, useEffect, useCallback} from 'react'
import { StyleSheet, Text, View, FlatList, TouchableOpacity, RefreshControl, ScrollView, SafeAreaView } from 'react-native'

const wait = (timeout) => {
  return new Promise(resolve => setTimeout(resolve, timeout));
}

const Get = ({navigation}) => {
  const [refreshing, setRefreshing] = useState(false);

  const onRefresh = useCallback(() => {
    setRefreshing(true);
    wait(1000).then(() => setRefreshing(false));
  }, []);

  const [user, setUser] = useState()

  const endpoint = 'https://gorest.co.in';
  const getUserData = async () => {
    try {
      let response = await fetch(`${endpoint}/public-api/users?page=75`);
      let json = await response.json();
      setUser(json.data);
    } catch(error) {
      console.error(error);
    }
  };

  useEffect(() => {
    const unsubscribe = navigation.addListener('focus', () => {
      getUserData();
    });

    return unsubscribe;
  }, [navigation])

  const renderItem = ({item}) => {
    return (
      <TouchableOpacity onPress={() => navigation.navigate('Details', {item: item})}>
        <View style={styles.flatListContainer}>
          <View style={{justifyContent: "flex-start"}}>
            <Text style={{fontWeight: 'bold'}}>{item.name}</Text>
            <Text>{item.email}</Text>
          </View>
        </View>
      </TouchableOpacity>
    )
  }

  return (
    <SafeAreaView style={styles.container}>
      <ScrollView 
        contentContainerStyle={styles.scrollView}
          refreshControl={
            <RefreshControl
              refreshing={refreshing}
              onRefresh={onRefresh}
            />
          }
      >
        <FlatList
          data={user}
          renderItem={renderItem}
          keyExtractor={(item) => item.id}
        />
      </ScrollView>
    </SafeAreaView>
  )
}


const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  scrollView: {
    flex: 1,
    backgroundColor: '#E9E9E9'
  },
  flatListContainer : {
    marginHorizontal: 20,
    marginVertical: 5, 
    borderBottomWidth: 1, 
    borderBottomColor: '#ccc',
    paddingVertical: 5
  }
})

export default Get