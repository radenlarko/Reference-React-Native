import React, { useState } from 'react';
import {
  Text,
  View,
  StyleSheet,
  TextInput,
  TouchableOpacity,
} from 'react-native';
import Constants from 'expo-constants';

export default function Post({route, navigation}) {
  // Menampung data
  const [name, setName] = useState('');
  const [gender, setGender] = useState('');
  const [email, setEmail] = useState('');
  const [status, setStatus] = useState('');

  const [loading, setLoading] = useState(false);

  const saveData = () => {
    setLoading(true);

    const myHeaders = new Headers();

    myHeaders.append(
      'Authorization',
      'Bearer a0bbbf81084293a753e003b143d1be1b2fe7cfe51a1538304dd7e9966aabd137'
    );

    myHeaders.append('Content-Type', 'application/json');

    const endpoint = 'https://gorest.co.in';

    fetch(`${endpoint}/public-api/users`, {
      method: 'POST',
      headers: myHeaders,
      body: JSON.stringify({
        name: name,
        email: email,
        gender: gender,
        status: status,
      }),
    })
      .then(() => {
        console.log('Berhasil post data');
        setLoading(false);
        navigation.navigate('Get');
      })
      .catch((error) => console.log(error));
  };

  return (
    <View style={styles.container}>
      <Text style={styles.title}>INPUT DATA</Text>
      <TextInput
        placeholder={'enter name'}
        value={name}
        onChangeText={(value) => setName(value)}
        style={styles.textInput}
      />
      <TextInput
        placeholder={'enter gender'}
        value={gender}
        onChangeText={(value) => setGender(value)}
        style={styles.textInput}
      />
      <TextInput
        placeholder={'enter email'}
        value={email}
        onChangeText={(value) => setEmail(value)}
        style={styles.textInput}
      />
      <TextInput
        placeholder={'enter status'}
        value={status}
        onChangeText={(value) => setStatus(value)}
        style={styles.textInput}
      />
      <TouchableOpacity onPress={saveData}>
        <View style={styles.button}>
          <Text style={styles.buttonText}>
            {loading ? 'Saving...' : 'Save'}
          </Text>
        </View>
      </TouchableOpacity>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    paddingHorizontal: 20,
    paddingTop: Constants.statusBarHeight,
    backgroundColor: '#ecf0f1',
    padding: 8,
  },
  title: {
    fontSize: 24,
    color: 'teal',
    textAlign: 'center',
    fontWeight: 'bold',
    marginTop: 60,
    marginBottom: 20,
  },
  textInput: {
    height: 50,
    borderWidth: 1,
    borderColor: '#ccc',
    borderRadius: 10,
    padding: 10,
    marginVertical: 10,
  },
  button: {
    backgroundColor: 'teal',
    padding: 10,
    borderRadius: 10,
    marginTop: 20,
  },
  buttonText: {
    color: 'white',
    textAlign: 'center',
  },
});
