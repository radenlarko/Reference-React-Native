import React from 'react';
import { createStackNavigator } from '@react-navigation/stack';
import { Ionicons } from '@expo/vector-icons';
import { Post, Get, Details } from '../components';

const Stack = createStackNavigator();

const rootStack = () => {
  return (
    <Stack.Navigator screenOptions={{
      headerStyle: {
        backgroundColor: 'teal',
      },
      headerTintColor: 'white'
    }}>
      <Stack.Screen name="Get" component={Get} 
        options={({navigation, route}) => ({
          title: 'NavProject',
          headerRight : () => (
            <Ionicons 
              name={'md-add'}
              size={25}
              color={'white'}
              style={{marginRight: 20}}
              onPress={() => navigation.navigate('Post')}
            />
          )
        })} 
      />
      <Stack.Screen name="Post" component={Post} />
      <Stack.Screen name="Details" component={Details} />
    </Stack.Navigator>
  );
};

export default rootStack;
