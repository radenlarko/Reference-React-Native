import React from 'react';
import { Text, View, StyleSheet, Button } from 'react-native';
import { createStackNavigator } from '@react-navigation/stack';
import { createMaterialBottomTabNavigator } from '@react-navigation/material-bottom-tabs';
import Constants from 'expo-constants';
import { Ionicons } from '@expo/vector-icons';

import HomeScreen from './HomeScreen';
import DetailsScreen from './DetailsScreen';
import ExploreScreen from './ExploreScreen';
import ProfileScreen from './ProfileScreen';

const HomeStack = createStackNavigator();
const DetailsStack = createStackNavigator();
const ExploreStack = createStackNavigator();
const ProfileStack = createStackNavigator();

const Tab = createMaterialBottomTabNavigator();

const MainTabScreen = () => {
  return (
    <Tab.Navigator initialRouteName="Home" activeColor="#FFF" >
      <Tab.Screen name="Home" component={HomeStackScreen} options={{
        tabBarLabel: 'Home',
        tabBarColor: '#009387',
        tabBarIcon: ({color}) => {
          return (
            <Ionicons name="ios-home" color={color} size={26} />
          )
        }
      }} />
      <Tab.Screen name="Details" component={DetailsStackScreen} options={{
        tabBarLabel: 'Details',
        tabBarColor: '#1F65FF',
        tabBarIcon: ({color}) => {
          return (
            <Ionicons name="ios-notifications" color={color} size={26} />
          )
        }
      }} />
      <Tab.Screen name="Explore" component={ExploreStackScreen} options={{
        tabBarLabel: 'Explore',
        tabBarColor: '#694FAD',
        tabBarIcon: ({color}) => {
          return (
            <Ionicons name="ios-aperture" color={color} size={26} />
          )
        }
      }} />
      <Tab.Screen name="Profile" component={ProfileStackScreen} options={{
        tabBarLabel: 'Profile',
        tabBarColor: '#D02860',
        tabBarIcon: ({color}) => {
          return (
            <Ionicons name="ios-person" color={color} size={26} />
          )
        }
      }} />
    </Tab.Navigator>
  )
}

const HomeStackScreen = ({navigation}) => {
  return (
    <HomeStack.Navigator screenOptions={{
        headerStyle: {
            backgroundColor: "#009387"
          },
        headerTintColor: "#FFF",
        headerTitleStyle: {
          fontWeight: "bold"
        },
        headerLeft: () => {
          return (
            <Ionicons 
              name={"ios-menu"}
              size={25}
              color={"white"}
              style={{marginLeft: 10}}
              onPress={() => navigation.openDrawer()}
            />
          )
        }
      }}>
        <HomeStack.Screen name="Home" component={HomeScreen} options={{ 
          title: "Overview"
        }} />
    </HomeStack.Navigator>
  )
}

const DetailsStackScreen = ({navigation}) => {
  return (
    <DetailsStack.Navigator screenOptions={{
        headerStyle: {
            backgroundColor: "#1F65FF"
          },
        headerTintColor: "#FFF",
        headerTitleStyle: {
          fontWeight: "bold"
        },
        headerLeft: () => {
          return (
            <Ionicons 
              name={"ios-menu"}
              size={25}
              color={"white"}
              style={{marginLeft: 10}}
              onPress={() => navigation.openDrawer()}
            />
          )
        }
      }}>
        <DetailsStack.Screen name="Details" component={DetailsScreen} />
    </DetailsStack.Navigator>
  )
}

const ExploreStackScreen = ({navigation}) => {
  return (
    <ExploreStack.Navigator screenOptions={{
        headerStyle: {
            backgroundColor: "#694FAD"
          },
        headerTintColor: "#FFF",
        headerTitleStyle: {
          fontWeight: "bold"
        },
        headerLeft: () => {
          return (
            <Ionicons 
              name={"ios-menu"}
              size={25}
              color={"white"}
              style={{marginLeft: 10}}
              onPress={() => navigation.openDrawer()}
            />
          )
        }
      }}>
        <ExploreStack.Screen name="Explore" component={ExploreScreen} />
    </ExploreStack.Navigator>
  )
}

const ProfileStackScreen = ({navigation}) => {
  return (
    <ProfileStack.Navigator screenOptions={{
        headerStyle: {
            backgroundColor: "#D02860"
          },
        headerTintColor: "#FFF",
        headerTitleStyle: {
          fontWeight: "bold"
        },
        headerLeft: () => {
          return (
            <Ionicons 
              name={"ios-menu"}
              size={25}
              color={"white"}
              style={{marginLeft: 10}}
              onPress={() => navigation.openDrawer()}
            />
          )
        }
      }}>
        <ProfileStack.Screen name="Profile" component={ProfileScreen} />
    </ProfileStack.Navigator>
  )
}

export default MainTabScreen;

const styles = StyleSheet.create({})