import React from 'react';
import { StyleSheet } from 'react-native';
import { NavigationContainer } from '@react-navigation/native';
import { createStackNavigator } from '@react-navigation/stack';
import { createDrawerNavigator } from '@react-navigation/drawer';
import Constants from 'expo-constants';
import { Ionicons } from '@expo/vector-icons';

import HomeScreen from './screens/HomeScreen';
import DetailsScreen from './screens/DetailsScreen';

const HomeStack = createStackNavigator();
const DetailsStack = createStackNavigator();
const Drawer = createDrawerNavigator();

const HomeStackScreen = ({navigation}) => {
  return (
    <HomeStack.Navigator screenOptions={{
        headerStyle: {
            backgroundColor: "#009387"
          },
        headerTintColor: "#FFF",
        headerTitleStyle: {
          fontWeight: "bold"
        },
        headerLeft: () => {
          return (
            <Ionicons 
              name={"ios-menu"}
              size={25}
              color={"white"}
              style={{marginLeft: 10}}
              onPress={() => navigation.openDrawer()}
            />
          )
        }
      }}>
        <HomeStack.Screen name="Home" component={HomeScreen} options={{ 
          title: "Overview"
        }} />
    </HomeStack.Navigator>
  )
}

const DetailsStackScreen = ({navigation}) => {
  return (
    <DetailsStack.Navigator screenOptions={{
        headerStyle: {
            backgroundColor: "#009387"
          },
        headerTintColor: "#FFF",
        headerTitleStyle: {
          fontWeight: "bold"
        },
        headerLeft: () => {
          return (
            <Ionicons 
              name={"ios-menu"}
              size={25}
              color={"white"}
              style={{marginLeft: 10}}
              onPress={() => navigation.openDrawer()}
            />
          )
        }
      }}>
        <DetailsStack.Screen name="Details" component={DetailsScreen} />
    </DetailsStack.Navigator>
  )
}

const App = () => {
  return (
    <NavigationContainer>
      <Drawer.Navigator initialRouteName="Home">
        <Drawer.Screen name="Home" component={HomeStackScreen} />
        <Drawer.Screen name="Details" component={DetailsStackScreen} />
      </Drawer.Navigator>
    </NavigationContainer>
  );
}

export default App;

const styles = StyleSheet.create({})