export default Users = [
  {
    id: 1,
    email: 'user1@email.com',
    username: 'user1',
    password: 'password1',
    userToken: 'token1231'
  },
  {
    id: 2,
    email: 'user2@email.com',
    username: 'user2',
    password: 'password2',
    userToken: 'token1232'
  },
  {
    id: 3,
    email: 'user3@email.com',
    username: 'user3',
    password: 'password3',
    userToken: 'token1233'
  }
];