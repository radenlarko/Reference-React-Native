import React from 'react';
import { Text, View, StyleSheet, Button, StatusBar } from 'react-native';
import Constants from 'expo-constants';
import { useTheme } from '@react-navigation/native';

const ExploreScreen = ({navigation}) => {
  const { colors } = useTheme();
  const theme = useTheme();
  
  return (
    <View style={styles.container}>
      <StatusBar barStyle={theme.dark ? "light-content" : "dark-content"} />
      <Text style={{color: colors.text}}>Explore Screen</Text>
      <Button title="Click Here" onPress={() => alert('Button Clicked')} />
    </View>
  );
}

export default ExploreScreen;

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    paddingTop: Constants.statusBarHeight,
    padding: 8,
  }
})