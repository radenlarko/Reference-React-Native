import React, {useState, useContext} from 'react';
import { View, Text, Button, StyleSheet, TouchableOpacity, Dimensions, Platform, TextInput, StatusBar, Alert } from 'react-native';
import * as Animatable from 'react-native-animatable';
import { LinearGradient } from 'expo-linear-gradient';
import { FontAwesome, Feather, MaterialIcons } from '@expo/vector-icons';
import { useTheme } from '@react-navigation/native';

import { AuthContext } from '../component/AuthContext';

import Users from '../models/Users';

const SignInScreen = ({navigation}) => {
  const { colors } = useTheme();
  
  const [data, setData] = useState({
    username: '',
    password: '',
    check_textInputChange: false,
    secureTextEntry: true,
    isValidUser: true,
    isValidPassword: true
  });

  const { signIn } = useContext(AuthContext);

  const textInputChange = (value) => {
    if (value.trim().length >= 4) {
      setData({
        ...data,
        username: value,
        check_textInputChange: true,
        isValidUser: true
      });
    } else {
      setData({
        ...data,
        username: value,
        check_textInputChange: false,
        isValidUser: false
      });
    }
  }

  const handlePasswordChange = (value) => {
    if ( value.trim().length >= 8 ) {
      setData({
        ...data,
        password: value,
        isValidPassword: true
      })
    } else{
      setData({
        ...data,
        password: value,
        isValidPassword: false
      })
    }
  }

  const updateSecureTextEntry = () => {
    setData({
      ...data,
      secureTextEntry: !data.secureTextEntry
    })
  }

  const loginHandle = (userName, password) => {
    const foundUser = Users.filter( item => {
      return userName == item.username && password == item.password;
    });

    if (data.username.length == 0 || data.password.length == 0) {
      Alert.alert('Wrong Input!', 'Username or Password field cannot be empty', [
        {text: 'Okay'}
      ]);
      return;
    }

    if (foundUser.length == 0) {
      Alert.alert('Invalid User', 'Username or Password is incorrect', [
        {text: 'Okay'}
      ]);
      return;
    }
    signIn(foundUser);
  }

  const handleValidUser = (value) => {
    if ( value.trim().length >= 4 ) {
      setData({
        ...data,
        isValidUser: true
      });
    } else {
      setData({
        ...data,
        isValidUser: false
      });
    }
  }

  const handleValidPassword = (value) => {
    if ( value.trim().length >= 8 ) {
      setData({
        ...data,
        isValidPassword: true
      });
    } else {
      setData({
        ...data,
        isValidPassword: false
      });
    }
  }

  return (
    <View style={styles.container}>
      <StatusBar backgroundColor="#009387" barStyle="light-content" />
      <Animatable.View 
        animation="bounceInRight"
        style={styles.header}
      >
        <Text style={styles.text_header}>Welcome!</Text>
      </Animatable.View>
      <Animatable.View 
        animation="fadeInUpBig"
        style={[styles.footer, {
          backgroundColor: colors.background
        }]}
      >
        <Text style={[styles.text_footer, {color: colors.text}]}>Email</Text>
        <View style={styles.action}>
          <FontAwesome 
            name="user-o"
            color={colors.text}
            size={20}
          />
          <TextInput 
            placeholder="enter your email"
            style={styles.textInput}
            autoCapitalize="none"
            onChangeText={(value) => textInputChange(value)}
            onEndEditing={(e) => handleValidUser(e.nativeEvent.text)}
          />
          {data.check_textInputChange ? 
          <Animatable.View>
            <Feather 
              name="check-circle"
              color="#24e35e"
              size={16}
            />
          </Animatable.View>
          : null}
        </View>
        {data.isValidUser ? null :
        <Animatable.View animation="fadeInLeft">
          <Text style={styles.errMsg}>Username must be 4 characters long.</Text>
        </Animatable.View>
        }
        <Text style={[styles.text_footer, {marginTop: 20, color: colors.text}]}>Password</Text>
        <View style={styles.action}>
          <FontAwesome 
            name="lock"
            color={colors.text}
            size={20}
          />
          <TextInput 
            placeholder="enter your password"
            secureTextEntry={data.secureTextEntry? true : false}
            style={styles.textInput}
            autoCapitalize="none"
            onChangeText={(value) => handlePasswordChange(value)}
            onEndEditing={(e) => handleValidPassword(e.nativeEvent.text)}
          />
          <TouchableOpacity
            onPress={updateSecureTextEntry}
          >
            {data.secureTextEntry ?
            <Feather 
              name="eye-off"
              color="grey"
              size={16}
            />
            :
            <Feather 
              name="eye"
              color="grey"
              size={16}
            />
            }
          </TouchableOpacity>
        </View>
        {data.isValidPassword ? null :
        <Animatable.View animation="fadeInLeft">
          <Text style={styles.errMsg}>Password must be 8 characters long.</Text>
        </Animatable.View>
        }
        <View>
          <TouchableOpacity style={styles.button} onPress={() => {loginHandle(data.username, data.password)}}>
            <LinearGradient
              colors={['#08d4c4', '#01ab9d']}
              style={styles.signIn}
            >
              <Text style={[styles.textSign, {color: 'white'}]}>Sign in</Text>
            </LinearGradient>
          </TouchableOpacity>
          <TouchableOpacity 
            onPress={() => navigation.navigate('SignUpScreen')}
            style={[styles.signIn, {
              borderColor: colors.text,
              borderWidth: 1,
              marginTop: 5
            }]}
          >
            <Text style={[styles.textSign, {color: colors.text}]}>Sign up</Text>
          </TouchableOpacity>
        </View>
      </Animatable.View>
    </View>
  )
}

export default SignInScreen;

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#009387'
  },
  header: {
    flex: 1,
    justifyContent: "flex-end",
    paddingHorizontal: 20,
    paddingBottom: 50
  },
  footer: {
    flex: 3,
    backgroundColor: '#fff',
    borderTopLeftRadius: 30,
    borderTopRightRadius: 30,
    paddingVertical: 30,
    paddingHorizontal: 20
  },
  text_header: {
    color: '#fff',
    fontWeight: "bold",
    fontSize: 30
  },
  text_footer: {
    color: '#05375a',
    fontSize: 18
  },
  action: {
    flexDirection: "row",
    marginTop: 10,
    borderBottomWidth: 1,
    borderBottomColor: '#f2f2f2',
    paddingBottom: 5
  },
  textInput: {
    flex: 1,
    marginTop: Platform.OS === 'ios' ? 0 : -12,
    paddingLeft: 10,
    color: 'grey'
  },
  button: {
    alignItems: "center",
    marginTop: 25
  },
  signIn: {
    width: '100%',
    height: 50,
    justifyContent: "center",
    alignItems: "center",
    borderRadius: 10
  },
  textSign: {
    fontSize: 18,
    fontWeight: "bold"
  },
  errMsg: {
    fontSize: 12, 
    color: '#ed0c2a'
  }
});